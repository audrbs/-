from django.urls import path
from main.views import signup_view, login_view, logout_view, home_view, calendar_view

urlpatterns = [
    path('', home_view, name='home'),  # 홈 화면으로 리다이렉트 (첫 페이지로 이동)
    path('signup/', signup_view, name='signup'),  # 회원가입 페이지 (회원가입 폼을 보여주는 뷰)
    path('login/', login_view, name='login'),  # 로그인 페이지 (로그인 폼을 보여주는 뷰)
    path('logout/', logout_view, name='logout'),  # 로그아웃 처리 후 홈으로 리다이렉트 (로그아웃 후 첫 페이지로 돌아가기)
    path('calendar/', calendar_view, name='calendar'),  # 스케줄 페이지 (사용자가 자신의 스케줄을 확인하고 관리할 수 있는 페이지)
]

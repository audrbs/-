from django.db import models
from django.contrib.auth.models import User

class Memo(models.Model):
    # 사용자와 메모를 연결하는 외래키
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # 사용자와 연결. 삭제 시 해당 사용자의 메모도 함께 삭제됨

    # 메모의 날짜를 저장하는 필드
    date = models.DateField()  # 날짜 필드, 메모가 작성된 날짜를 저장

    # 메모의 내용을 저장하는 필드
    memo_text = models.TextField()  # 텍스트 필드, 실제 메모 내용

    # 메모를 문자열로 표현하기 위한 메서드
    def __str__(self):
        return f"Memo for {self.date} by {self.user.username}"  # 메모를 '날짜 - 사용자' 형식으로 출력

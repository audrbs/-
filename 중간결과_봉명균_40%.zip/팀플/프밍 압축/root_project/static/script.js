// 기존 코드: .content-box 클릭 시 알림
document.querySelectorAll('.content-box').forEach(box => {
    // 모든 .content-box 요소에 클릭 이벤트 리스너 추가
    box.addEventListener('click', function () {
        // 클릭한 content-box의 텍스트를 alert로 표시
        alert(`${this.innerText}를 선택하셨습니다.`);
    });
});

// 날짜 클릭 시 메모 폼을 보이게 하는 기능 추가
document.querySelectorAll('.day-button').forEach(button => {
    // 모든 .day-button 요소에 클릭 이벤트 리스너 추가
    button.addEventListener('click', function () {
        // 클릭한 날짜(day-button)의 텍스트 값을 가져와서 (공백 제거)
        const day = this.textContent.trim();
        
        // 메모 폼의 숨겨진 날짜 입력 필드에 해당 날짜 값을 설정
        document.getElementById('memo-date').value = day;
        
        // 메모 폼을 화면에 표시 (숨겨져 있던 폼을 보이게)
        document.getElementById('memo-form').style.display = 'block';
    });
});

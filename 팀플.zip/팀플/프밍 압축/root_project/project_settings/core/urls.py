from django.urls import path
from main.views import (
    signup_view, login_view, logout_view, home_view, 
    calendar_view, lecture_view, grade1_view, grade2_view, 
    grade3_view, grade4_view, search_suggestions, 
    search_results, detail_view, save_memo, load_memos
)
from django.contrib import admin

urlpatterns = [
    path('', home_view, name='home'),  # 홈 화면으로 리다이렉트 (첫 페이지로 이동)
    path('signup/', signup_view, name='signup'),  # 회원가입 페이지 (회원가입 폼을 보여주는 뷰)
    path('login/', login_view, name='login'),  # 로그인 페이지 (로그인 폼을 보여주는 뷰)
    path('logout/', logout_view, name='logout'),  # 로그아웃 처리 후 홈으로 리다이렉트 (로그아웃 후 첫 페이지로 돌아가기)
    path('calendar/', calendar_view, name='calendar'),  # 스케줄 페이지 (사용자가 자신의 스케줄을 확인하고 관리할 수 있는 페이지)
    path('lecture/', lecture_view, name='lecture'),
    path('lecture/grade1/', grade1_view, name='grade1'),  # 강의 정보 URL
    path('lecture/grade2/', grade2_view, name='grade2'),
    path('lecture/grade3/', grade3_view, name='grade3'),
    path('lecture/grade4/', grade4_view, name='grade4'),
    path('search-suggestions', search_suggestions, name='search_suggestions'),
    path('search-results', search_results, name='search_results'),
    path('admin/', admin.site.urls),  # 관리자 페이지 URL 등록
    path('detail/<int:id>/', detail_view, name='detail'),  # 상세 페이지 URL
    path('api/save-memo/', save_memo, name='save_memo'),  # 메모 저장 API
    path('api/load-memos/', load_memos, name='load_memos'),  # 메모 불러오기 API
]

#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
# 이 파일은 Django 프로젝트에서 관리 작업을 실행하기 위한 명령줄 유틸리티입니다.

import os
import sys

def main():
    """Run administrative tasks."""
    # 환경 변수 'DJANGO_SETTINGS_MODULE'에 설정을 지정하지 않았다면 'core.settings'를 기본값으로 설정합니다.
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

    try:
        # Django의 관리 명령어를 실행하는 'execute_from_command_line' 함수를 임포트합니다.
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        # Django가 설치되지 않았거나 가상 환경을 활성화하지 않은 경우 오류를 발생시킵니다.
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc

    # 명령어 라인 인자(sys.argv)를 받아서 Django 관리 명령을 실행합니다.
    execute_from_command_line(sys.argv)

# 이 파일이 직접 실행될 경우 main() 함수를 호출합니다.
if __name__ == '__main__':
    main()

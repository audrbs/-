from django.db import models
from django.contrib.auth.models import User

class SearchData(models.Model):
    title = models.CharField(max_length=255)  # 제목
    content = models.TextField()             # 블로그 형식의 상세 정보
    keywords = models.TextField()            # 연관 키워드 (콤마로 구분)

    def __str__(self):
        return self.title

class Memo(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    text = models.TextField(blank=True, null=True)

    def __str__(self):
        return f'{self.date}: {self.text}'
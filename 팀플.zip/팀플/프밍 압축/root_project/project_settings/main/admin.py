from django.contrib import admin
from main.models import SearchData, Memo
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin

@admin.register(SearchData)
class SearchDataAdmin(admin.ModelAdmin):
    list_display = ('title', 'keywords')  # 목록에서 보여줄 필드
    search_fields = ('title', 'keywords')  # 검색 가능 필드

@admin.register(Memo)
class MemoAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'text')  # 관리자 페이지 목록에서 표시할 필드
    list_filter = ('user', 'date')  # 필터링 옵션
    search_fields = ('user__username', 'text')  # 검색 필드
    ordering = ('-date',)  # 정렬 순서 (최신 날짜 기준)

    # 필드 수정 가능
    fields = ('user', 'date', 'text')  # 수정 가능한 필드 정의

# UserAdmin 커스터마이징
class CustomUserAdmin(UserAdmin):
    # 관리자 페이지에 표시할 필드 지정
    list_display = ('username', 'email', 'password', 'is_staff')
    # 검색 가능한 필드
    search_fields = ('username', 'email')
    # 필드 정렬 순서
    ordering = ('date_joined',)

    # 유저 변경 페이지에서 수정 가능한 필드
    fieldsets = (
        (None, {'fields': ('username', 'email', 'password')}),
        ('Permissions', {'fields': ('is_staff', 'is_active')}),
    )
    # 유저 추가 시 필요한 필드
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2'),
        }),
    )


# 기본 UserAdmin을 교체
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
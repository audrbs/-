from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from .models import Memo  # Memo 모델 임포트
import calendar

# 캘린더를 생성하는 함수 (년, 월을 기준으로 주별 날짜 배열 반환)
def create_calendar(year, month):
    cal = calendar.Calendar(firstweekday=6)  # 일요일을 첫 번째 날로 설정 (week starts from Sunday)
    month_days = cal.monthdayscalendar(year, month)  # 해당 월의 날짜들 반환 (2D 배열로 주 단위로 날짜들 반환)
    return month_days

# 홈 화면을 렌더링하는 뷰
def home_view(request):
    # 첫 화면을 렌더링합니다.
    return render(request, 'index.html')

# 회원가입 뷰
def signup_view(request):
    # 이미 로그인된 사용자가 회원가입 페이지에 접근하려면 홈으로 리다이렉트
    if request.user.is_authenticated:
        return redirect('home')  # 로그인 상태이면 홈으로 이동

    if request.method == 'POST':
        form = UserCreationForm(request.POST)  # 제출된 폼 데이터로 UserCreationForm 객체 생성
        if form.is_valid():  # 폼 검증 통과 시
            user = form.save()  # 새 사용자 저장
            login(request, user)  # 새로 생성된 사용자로 로그인 처리
            return redirect('home')  # 로그인 후 홈 페이지로 리다이렉트
    else:
        form = UserCreationForm()  # GET 요청 시 빈 폼을 렌더링
    
    return render(request, 'signup.html', {'form': form})  # 회원가입 페이지 렌더링

# 로그인 뷰
def login_view(request):
    # 이미 로그인된 사용자가 로그인 페이지에 접근하면 홈으로 리다이렉트
    if request.user.is_authenticated:
        return redirect('home')  # 로그인 상태이면 홈으로 이동

    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)  # 로그인 폼 데이터로 AuthenticationForm 객체 생성
        if form.is_valid():  # 폼 검증 통과 시
            user = form.get_user()  # 인증된 사용자 가져오기
            login(request, user)  # 로그인 처리
            return redirect('home')  # 로그인 후 홈 페이지로 리다이렉트
        else:
            messages.error(request, '아이디 또는 비밀번호가 올바르지 않습니다.')  # 로그인 실패 시 오류 메시지 표시
    else:
        form = AuthenticationForm()  # GET 요청 시 빈 로그인 폼 렌더링

    return render(request, 'login.html', {'form': form})  # 로그인 페이지 렌더링

# 로그아웃 뷰
def logout_view(request):
    logout(request)  # 사용자를 로그아웃 처리
    return redirect('home')  # 로그아웃 후 홈 페이지로 리다이렉트

# 캘린더와 메모를 보여주는 뷰
def calendar_view(request):
    # 로그인 여부 체크
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트

    # 현재 날짜를 기준으로 캘린더와 메모를 처리
    year = 2024  # 캘린더 년도 (임시로 2024년 설정)
    month = 1  # 캘린더 월 (임시로 1월 설정)
    calendar_data = create_calendar(year, month)  # 캘린더 데이터 생성

    # 해당 날짜에 대한 메모를 불러오기
    memos = Memo.objects.filter(user=request.user, date__year=year, date__month=month)  # 로그인한 사용자의 해당 월의 메모를 가져옴

    # 캘린더와 메모를 템플릿으로 전달
    return render(request, 'calendar.html', {'calendar': calendar_data, 'memos': memos, 'year': year, 'month': month})

# 메모를 저장하는 뷰 (POST 요청 처리)
def save_memo(request):
    # 로그인 여부 체크
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트

    if request.method == 'POST':
        day = request.POST.get('day')  # 메모를 추가할 날짜
        memo_text = request.POST.get('memo')  # 메모 내용

        # 메모 모델을 사용하여 메모 저장
        Memo.objects.create(user=request.user, date=day, memo_text=memo_text)  # 새 메모 객체 생성 후 저장

        return redirect('calendar')  # 메모 저장 후 캘린더 페이지로 리다이렉트

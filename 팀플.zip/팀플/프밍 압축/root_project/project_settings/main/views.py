from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from .models import SearchData, Memo
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.db import models
import calendar
import json

# 캘린더를 생성하는 함수 (년, 월을 기준으로 주별 날짜 배열 반환)
def create_calendar(year, month):
    cal = calendar.Calendar(firstweekday=6)  # 일요일을 첫 번째 날로 설정 (week starts from Sunday)
    month_days = cal.monthdayscalendar(year, month)  # 해당 월의 날짜들 반환 (2D 배열로 주 단위로 날짜들 반환)
    return month_days

# 홈 화면을 렌더링하는 뷰
def home_view(request):
    # 첫 화면을 렌더링합니다.
    return render(request, 'index.html')

# 회원가입 뷰
def signup_view(request):
    errors = {}  # 에러 메시지를 저장하는 딕셔너리
    # 이미 로그인된 사용자가 회원가입 페이지에 접근하려면 홈으로 리다이렉트
    if request.user.is_authenticated:
        return redirect('home')  # 로그인 상태이면 홈으로 이동

    if request.method == 'POST':
        form = UserCreationForm(request.POST)  # 제출된 폼 데이터로 UserCreationForm 객체 생성
        if form.is_valid():  # 폼 검증 통과 시
            print("폼이 유효합니다.")  # 디버깅 메시지
            user = form.save()  # 새 사용자 저장
            login(request, user)  # 새로 생성된 사용자로 로그인 처리
            return redirect('home')  # 로그인 후 홈 페이지로 리다이렉트
        else:
            # 각 필드의 에러 메시지를 딕셔너리에 저장
            for field, error_list in form.errors.items():
                errors[field] = error_list
            print("폼이 유효하지 않습니다.")  # 유효성 검사를 통과하지 못했을 때
            print(form.errors)  # 에러 메시지 출력
    else:
        form = UserCreationForm()  # GET 요청 시 빈 폼을 렌더링
    
    return render(request, 'signup.html', {'form': form, 'errors': errors})  # 회원가입 페이지 렌더링, 에러 메시지 출력

# 로그인 뷰
def login_view(request):
    # 이미 로그인된 사용자가 로그인 페이지에 접근하면 홈으로 리다이렉트
    if request.user.is_authenticated:
        return redirect('home')  # 로그인 상태이면 홈으로 이동

    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)  # 로그인 폼 데이터로 AuthenticationForm 객체 생성
        if form.is_valid():  # 폼 검증 통과 시
            user = form.get_user()  # 인증된 사용자 가져오기
            login(request, user)  # 로그인 처리
            return redirect('home')  # 로그인 후 홈 페이지로 리다이렉트
        else:
            messages.error(request, '아이디 또는 비밀번호가 올바르지 않습니다.')  # 로그인 실패 시 오류 메시지 표시
    else:
        form = AuthenticationForm()  # GET 요청 시 빈 로그인 폼 렌더링

    return render(request, 'login.html', {'form': form})  # 로그인 페이지 렌더링

# 로그아웃 뷰
def logout_view(request):
    logout(request)  # 사용자를 로그아웃 처리
    return redirect('home')  # 로그아웃 후 홈 페이지로 리다이렉트

# 캘린더를 보여주는 뷰
def calendar_view(request):
    # 로그인 여부 체크
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트

    # 현재 날짜를 기준으로 캘린더를 처리
    year = 2024  # 캘린더 년도 (임시로 2024년 설정)
    month = 1  # 캘린더 월 (임시로 1월 설정)
    calendar_data = create_calendar(year, month)  # 캘린더 데이터 생성

    # 캘린더를 템플릿으로 전달
    return render(request, 'calendar.html', {'calendar': calendar_data, 'year': year, 'month': month})

# 메모 저장 API
@csrf_exempt
@login_required
def save_memo(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            date = data.get('date')
            text = data.get('text')
            # 메모 저장 로직
            memo, created = request.user.memo_set.update_or_create(date=date, defaults={'text': text})
            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'})

# 메모 불러오기 API
@csrf_exempt
@login_required
def load_memos(request):
    if request.method == 'GET':
        try:
            memos = request.user.memo_set.values('date', 'text')  # 사용자와 연결된 메모 조회
            return JsonResponse(list(memos), safe=False)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'})

def lecture_view(request):
    return render(request, 'lecture.html')

# 강의 정보 UI
def grade1_view(request):
    lectures = [
        {"title": "프로그래밍및실습2", "professor": "김성신", "time": "화 10:00 AM ~ 11:50 AM"},
        {"title": "오픈소스기초설계", "professor": "김성흠", "time": "월 10:30 AM ~ 11:45 AM"},
        {"title": "이산수학", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인공지능입문", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "고전읽기와 상상력", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인문학과 성서", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "AI와 데이터기초", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
    ]
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트
    return render(request, 'grade1.html', {'lectures': lectures})

def grade2_view(request):
    lectures = [
        {"title": "프로그래밍및실습2", "professor": "김성신", "time": "화 10:00 AM ~ 11:50 AM"},
        {"title": "오픈소스기초설계", "professor": "김성흠", "time": "월 10:30 AM ~ 11:45 AM"},
        {"title": "이산수학", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인공지능입문", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "고전읽기와 상상력", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인문학과 성서", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "AI와 데이터기초", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
    ]
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트
    return render(request, 'grade2.html', {'lectures': lectures})

def grade3_view(request):
    lectures = [
        {"title": "프로그래밍및실습2", "professor": "김성신", "time": "화 10:00 AM ~ 11:50 AM"},
        {"title": "오픈소스기초설계", "professor": "김성흠", "time": "월 10:30 AM ~ 11:45 AM"},
        {"title": "이산수학", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인공지능입문", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "고전읽기와 상상력", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인문학과 성서", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "AI와 데이터기초", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
    ]
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트
    return render(request, 'grade3.html', {'lectures': lectures})

def grade4_view(request):
    lectures = [
        {"title": "프로그래밍및실습2", "professor": "김성신", "time": "화 10:00 AM ~ 11:50 AM"},
        {"title": "오픈소스기초설계", "professor": "김성흠", "time": "월 10:30 AM ~ 11:45 AM"},
        {"title": "이산수학", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인공지능입문", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "고전읽기와 상상력", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "인문학과 성서", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
        {"title": "AI와 데이터기초", "professor": "정규식", "time": "월 12:00 PM ~ 01:15 PM"},
    ]
    if not request.user.is_authenticated:
        return redirect('login')  # 로그인하지 않으면 로그인 페이지로 리다이렉트
    return render(request, 'grade4.html', {'lectures': lectures})

def search_suggestions(request):
    query = request.GET.get('q', '')  # 사용자가 입력한 키워드
    if query:
        suggestions = SearchData.objects.filter(
            keywords__icontains=query
        ).values('title', 'id')  # 제목과 ID만 반환
    else:
        suggestions = []
    return JsonResponse(list(suggestions), safe=False)

def search_results(request):
    query = request.GET.get('q', '')
    results = SearchData.objects.filter(
        keywords__icontains=query
    )
    return render(request, 'search_results.html', {'results': results})

def detail_view(request, id):
    # ID로 검색 데이터를 가져옴
    item = get_object_or_404(SearchData, id=id)
    return render(request, 'detail.html', {'item': item})
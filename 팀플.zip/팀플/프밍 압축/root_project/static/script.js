// 기존 코드: .content-box 클릭 시 알림
document.querySelectorAll('.content-box').forEach(box => {
    // 모든 .content-box 요소에 클릭 이벤트 리스너 추가
    box.addEventListener('click', function () {
        // 클릭한 content-box의 텍스트를 alert로 표시
        alert(`${this.innerText}를 선택하셨습니다.`);
    });
});

// 날짜 계산을 위한 유틸리티 함수
function generateCalendar(year, month) {
    const firstDay = new Date(year, month - 1, 1).getDay(); // 월의 첫날 요일 (0: 일요일)
    const daysInMonth = new Date(year, month, 0).getDate(); // 해당 월의 총 일 수

    const calendar = [];
    let week = Array(firstDay).fill(0); // 첫 주 빈칸

    for (let day = 1; day <= daysInMonth; day++) {
        week.push(day);
        if (week.length === 7) {
            calendar.push(week);
            week = [];
        }
    }

    if (week.length > 0) {
        week = week.concat(Array(7 - week.length).fill(0)); // 마지막 주 빈칸 채우기
        calendar.push(week);
    }

    return calendar;
}

// 달력을 업데이트하는 함수
function updateCalendar(year, month) {
    const calendarData = generateCalendar(year, month);
    const calendarTableBody = document.querySelector(".calendar-table tbody");

    // 기존 달력 내용 삭제
    calendarTableBody.innerHTML = "";

    // 새로운 달력 데이터를 기반으로 테이블 작성
    calendarData.forEach(week => {
        const row = document.createElement("tr");
        week.forEach(day => {
            const cell = document.createElement("td");
            cell.className = day === 0 ? "empty" : ""; // 빈칸 클래스 추가
            if (day !== 0) {
                const dayDiv = document.createElement("div");
                dayDiv.className = "day";
                dayDiv.textContent = day;
                cell.appendChild(dayDiv);
            }
            row.appendChild(cell);
        });
        calendarTableBody.appendChild(row);
    });
}

// 드롭다운 버튼 및 리스트 요소 가져오기
const monthDropdownBtn = document.getElementById('monthDropdownBtn');
const monthDropdownList = document.getElementById('monthDropdownList');
const selectedMonth = document.getElementById('selectedMonth');
const yearDropdownBtn = document.getElementById('yearDropdownBtn');
const yearDropdownList = document.getElementById('yearDropdownList');
const selectedYear = document.getElementById('selectedYear');

// 월 드롭다운 토글
monthDropdownBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    const isHidden = monthDropdownList.classList.contains('hidden');
    monthDropdownList.classList.toggle('hidden');
    console.log('Month Dropdown Visibility:', !isHidden, monthDropdownList);
    yearDropdownList.classList.add('hidden'); // 연도 드롭다운 닫기
});

// 월 선택 이벤트
monthDropdownList.addEventListener('click', (event) => {
    if (event.target.tagName === 'LI') {
        selectedMonth.textContent = event.target.textContent; // 선택된 월 표시
        monthDropdownList.classList.add('hidden'); // 드롭다운 닫기

        const newMonth = parseInt(event.target.textContent.replace("월", ""));
        const newYear = parseInt(selectedYear.textContent);
        updateCalendar(newYear, newMonth); // 달력 업데이트
    }
    event.stopPropagation();
});

// 연도 드롭다운 토글
yearDropdownBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    const isHidden = yearDropdownList.classList.contains('hidden');
    yearDropdownList.classList.toggle('hidden');
    console.log('Year Dropdown Visibility:', !isHidden, yearDropdownList);
    monthDropdownList.classList.add('hidden'); // 월 드롭다운 닫기
});

// 연도 선택 이벤트
yearDropdownList.addEventListener('click', (event) => {
    if (event.target.tagName === 'LI') {
        selectedYear.textContent = event.target.textContent; // 선택된 연도 표시
        yearDropdownList.classList.add('hidden'); // 드롭다운 닫기

        const newYear = parseInt(event.target.textContent);
        const newMonth = parseInt(selectedMonth.textContent.replace("월", ""));
        updateCalendar(newYear, newMonth); // 달력 업데이트
    }
    event.stopPropagation();
});

// 드롭다운 외부 클릭 시 닫기
document.addEventListener('click', () => {
    monthDropdownList.classList.add('hidden');
    yearDropdownList.classList.add('hidden');
});

// 초기화: 현재 연도와 월로 달력 설정
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;
selectedYear.textContent = `${currentYear}`;
selectedMonth.textContent = `${currentMonth}월`;
updateCalendar(currentYear, currentMonth);

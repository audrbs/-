// 기존 코드: .content-box 클릭 시 알림
document.querySelectorAll('.content-box').forEach(box => {
    // 모든 .content-box 요소에 클릭 이벤트 리스너 추가
    box.addEventListener('click', function () {
        // 클릭한 content-box의 텍스트를 alert로 표시
        alert(`${this.innerText}를 선택하셨습니다.`);
    });
});

// 날짜 계산을 위한 유틸리티 함수
function generateCalendar(year, month) {
    const firstDay = new Date(year, month - 1, 1).getDay(); // 월의 첫날 요일 (0: 일요일)
    const daysInMonth = new Date(year, month, 0).getDate(); // 해당 월의 총 일 수

    const calendar = [];
    let week = Array(firstDay).fill(0); // 첫 주 빈칸

    for (let day = 1; day <= daysInMonth; day++) {
        week.push(day);
        if (week.length === 7) {
            calendar.push(week);
            week = [];
        }
    }

    if (week.length > 0) {
        week = week.concat(Array(7 - week.length).fill(0)); // 마지막 주 빈칸 채우기
        calendar.push(week);
    }

    return calendar;
}

// 달력을 업데이트하는 함수
function updateCalendar(year, month) {
    const calendarData = generateCalendar(year, month);
    const calendarTableBody = document.querySelector(".calendar-table tbody");

    // 기존 달력 내용 삭제
    calendarTableBody.innerHTML = "";

    // 새로운 달력 데이터를 기반으로 테이블 작성
    calendarData.forEach(week => {
        const row = document.createElement("tr");
        week.forEach(day => {
            const cell = document.createElement("td");
            cell.className = day === 0 ? "empty" : ""; // 빈칸 클래스 추가
            if (day !== 0) {
                const dayDiv = document.createElement("div");
                dayDiv.className = "day";
                dayDiv.textContent = day;
                cell.appendChild(dayDiv);
            }
            row.appendChild(cell);
        });
        calendarTableBody.appendChild(row);
    });
}

// 드롭다운 버튼 및 리스트 요소 가져오기
const monthDropdownBtn = document.getElementById('monthDropdownBtn');
const monthDropdownList = document.getElementById('monthDropdownList');
const selectedMonth = document.getElementById('selectedMonth');
const yearDropdownBtn = document.getElementById('yearDropdownBtn');
const yearDropdownList = document.getElementById('yearDropdownList');
const selectedYear = document.getElementById('selectedYear');

// 월 드롭다운 토글
monthDropdownBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    const isHidden = monthDropdownList.classList.contains('hidden');
    monthDropdownList.classList.toggle('hidden');
    console.log('Month Dropdown Visibility:', !isHidden, monthDropdownList);
    yearDropdownList.classList.add('hidden'); // 연도 드롭다운 닫기
});

// 월 선택 이벤트
monthDropdownList.addEventListener('click', (event) => {
    if (event.target.tagName === 'LI') {
        selectedMonth.textContent = event.target.textContent; // 선택된 월 표시
        monthDropdownList.classList.add('hidden'); // 드롭다운 닫기

        const newMonth = parseInt(event.target.textContent.replace("월", ""));
        const newYear = parseInt(selectedYear.textContent);
        updateCalendar(newYear, newMonth); // 달력 업데이트
    }
    event.stopPropagation();
});

// 연도 드롭다운 토글
yearDropdownBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    const isHidden = yearDropdownList.classList.contains('hidden');
    yearDropdownList.classList.toggle('hidden');
    console.log('Year Dropdown Visibility:', !isHidden, yearDropdownList);
    monthDropdownList.classList.add('hidden'); // 월 드롭다운 닫기
});

// 연도 선택 이벤트
yearDropdownList.addEventListener('click', (event) => {
    if (event.target.tagName === 'LI') {
        selectedYear.textContent = event.target.textContent; // 선택된 연도 표시
        yearDropdownList.classList.add('hidden'); // 드롭다운 닫기

        const newYear = parseInt(event.target.textContent);
        const newMonth = parseInt(selectedMonth.textContent.replace("월", ""));
        updateCalendar(newYear, newMonth); // 달력 업데이트
    }
    event.stopPropagation();
});

// 드롭다운 외부 클릭 시 닫기
document.addEventListener('click', () => {
    monthDropdownList.classList.add('hidden');
    yearDropdownList.classList.add('hidden');
});

// 검색창 입력 시 호출되는 함수
function fetchSuggestions(query) {
    const suggestionsBox = document.getElementById('suggestions');
    if (query.length > 0) {
        fetch(`/search-suggestions?q=${query}`) // 연관 검색어 데이터 가져오기
            .then(response => response.json())
            .then(data => {
                suggestionsBox.innerHTML = ''; // 이전 연관 검색어 초기화
                data.forEach(item => {
                    const suggestion = document.createElement('div');
                    suggestion.className = 'suggestion-item';
                    suggestion.textContent = item.title; // 검색어 제목 표시
                    suggestion.onclick = () => {
                        document.getElementById('search-input').value = item.title; // 클릭 시 검색창에 입력
                        suggestionsBox.innerHTML = ''; // 연관 검색어 초기화
                    };
                    suggestionsBox.appendChild(suggestion); // 연관 검색어 추가
                });
            })
            .catch(error => {
                console.error('Error fetching suggestions:', error);
                suggestionsBox.innerHTML = ''; // 오류 발생 시 초기화
            });
    } else {
        suggestionsBox.innerHTML = ''; // 검색어 없으면 초기화
    }
}


// 검색 실행 시 호출되는 함수
function executeSearch() {
    const query = document.getElementById('search-input').value;
    if (query.trim() !== '') {
        window.location.href = `/search-results?q=${query}`; // 검색 결과 페이지로 이동
    }
    return false; // 폼 제출을 막음
}

//팝업 띄우기
function showPopup(title, professor, time) {
    document.getElementById('popup-title').innerText = title;
    document.getElementById('popup-professor').innerText = professor;
    document.getElementById('popup-time').innerText = time;
    document.getElementById('popup').style.display = 'block';
}

//팝업 닫기
function closePopup() {
    document.getElementById('popup').style.display = 'none';
}

const memoModal = document.getElementById('memoModal');
const memoInput = document.getElementById('memoInput');
const saveMemoButton = document.getElementById('saveMemo');
const cancelMemoButton = document.getElementById('cancelMemo');

let selectedDate = null; // 현재 선택된 날짜
const memos = {}; // 메모 저장소 (key: 날짜, value: 메모 내용)

// 서버에서 메모 데이터를 가져오는 함수
async function loadMemos() {
    try {
        const response = await fetch('/api/load-memos/');
        if (response.ok) {
            const data = await response.json();
            data.forEach(memo => {
                memos[memo.date] = memo.text; // 서버에서 받은 메모 데이터를 로컬에 저장
                displayMemoIndicator(memo.date); // 기존 메모 표시
            });
        } else {
            console.error('Failed to load memos');
        }
    } catch (error) {
        console.error('Error fetching memos:', error);
    }
}

// 메모를 서버에 저장하는 함수
async function saveMemoToServer(date, text) {
    try {
        const response = await fetch('/api/save-memo/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken() // 수정된 getCSRFToken 함수 호출
            },
            body: JSON.stringify({ date, text })
        });

        if (!response.ok) {
            console.error('Failed to save memo');
        }
    } catch (error) {
        console.error('Error saving memo:', error);
    }
}

// CSRF 토큰 가져오기 함수
function getCSRFToken() {
    if (typeof csrfToken !== 'undefined') {
        return csrfToken; // 선언된 CSRF 토큰을 반환
    }
    console.error('CSRF token is undefined.');
    return null;
}

// 날짜 셀 클릭 이벤트 바인딩
function bindDateClickEvents() {
    document.querySelectorAll('.calendar-table td').forEach(cell => {
        cell.addEventListener('click', function () {
            if (!this.classList.contains('empty')) {
                selectedDate = this.dataset.date; // 셀의 data-date 속성을 가져옴
                memoInput.value = memos[selectedDate] || ''; // 기존 메모 불러오기
                memoModal.classList.remove('hidden'); // 모달 표시
            }
        });
    });
}

// 메모 저장
saveMemoButton.addEventListener('click', async () => {
    if (selectedDate) {
        const memoText = memoInput.value.trim();
        if (memoText) {
            memos[selectedDate] = memoText; // 메모 저장
            await saveMemoToServer(selectedDate, memoText); // 서버에 메모 저장
            displayMemoIndicator(selectedDate); // 메모 표시
        } else {
            delete memos[selectedDate]; // 빈 메모는 삭제
            await saveMemoToServer(selectedDate, ''); // 서버에서 메모 삭제
            removeMemoIndicator(selectedDate); // 메모 표시 제거
        }
        memoModal.classList.add('hidden'); // 모달 닫기
    }
});

// 메모 취소
cancelMemoButton.addEventListener('click', () => {
    memoModal.classList.add('hidden'); // 모달 닫기
});

// 메모 동그라미 표시
function displayMemoIndicator(date) {
    const cell = document.querySelector(`.calendar-table td[data-date="${date}"]`);
    if (!cell) return;

    if (!cell.querySelector('.memo-indicator')) {
        const indicator = document.createElement('div');
        indicator.classList.add('memo-indicator');
        indicator.style.position = 'absolute';
        indicator.style.top = '5px';
        indicator.style.right = '5px';
        indicator.style.width = '10px';
        indicator.style.height = '10px';
        indicator.style.borderRadius = '50%';
        indicator.style.backgroundColor = 'red'; // 빨간색 동그라미
        cell.style.position = 'relative'; // 부모 요소 위치 설정
        cell.appendChild(indicator);
    }
}

// 메모 동그라미 제거
function removeMemoIndicator(date) {
    const cell = document.querySelector(`.calendar-table td[data-date="${date}"]`);
    if (!cell) return;

    const indicator = cell.querySelector('.memo-indicator');
    if (indicator) {
        indicator.remove();
    }
}

// 초기화 시 각 셀에 data-date 속성 추가 및 클릭 이벤트 바인딩
function initializeCalendarCells() {
    document.querySelectorAll('.calendar-table td').forEach(cell => {
        if (!cell.classList.contains('empty')) {
            const day = cell.querySelector('.day');
            if (day) {
                const currentMonth = document.getElementById('selectedMonth').textContent.replace('월', '');
                const currentYear = document.getElementById('selectedYear').textContent;
                const fullDate = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day.textContent).padStart(2, '0')}`;
                cell.dataset.date = fullDate; // data-date 속성 추가

                if (memos[fullDate]) {
                    displayMemoIndicator(fullDate); // 기존 메모 표시
                }
            }
        }
    });
    bindDateClickEvents(); // 셀 클릭 이벤트 바인딩
}

// 달력을 업데이트하는 함수
function updateCalendar(year, month) {
    const calendarData = generateCalendar(year, month);
    const calendarTableBody = document.querySelector('.calendar-table tbody');

    // 기존 달력 내용 삭제
    calendarTableBody.innerHTML = "";

    // 새로운 달력 데이터를 기반으로 테이블 작성
    calendarData.forEach(week => {
        const row = document.createElement("tr");
        week.forEach(day => {
            const cell = document.createElement("td");
            cell.className = day === 0 ? "empty" : ""; // 빈칸 클래스 추가
            if (day !== 0) {
                const dayDiv = document.createElement("div");
                dayDiv.className = "day";
                dayDiv.textContent = day;
                cell.appendChild(dayDiv);
            }
            row.appendChild(cell);
        });
        calendarTableBody.appendChild(row);
    });

    initializeCalendarCells(); // 새로 생성된 셀 초기화
}

// 초기화: 현재 연도와 월로 달력 설정
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;

selectedYear.textContent = `${currentYear}`;
selectedMonth.textContent = `${currentMonth}월`;

updateCalendar(currentYear, currentMonth);
loadMemos(); // 페이지 로드 시 기존 메모 불러오기